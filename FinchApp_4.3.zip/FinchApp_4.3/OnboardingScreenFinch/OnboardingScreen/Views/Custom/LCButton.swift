//
//  LCButton.swift
//  OnboardingScreen
//
//  Created by elisa on 17.05.2020.
//  Copyright © 2020 elisa. All rights reserved.
//

import SwiftUI

struct LCButton: View {
    var text = "Пропустить"
    var action: (()->()) = {}
    
    var body: some View {
      Button(action: {
        self.action()
      }) {
        HStack {
            Text(text)
                .bold()
                .frame(minWidth: 0, maxWidth: .infinity)
                .padding(.vertical)
                .accentColor(Color.white)
                .background(Color("accentColor"))
                .cornerRadius(30)
            }
        }
    }
}

struct LCButton_Previews: PreviewProvider {
    static var previews: some View {
        LCButton()
    }
}
