//
//  SignupView.swift
//  OnboardingScreen
//
//  Created by elisa on 17.05.2020.
//  Copyright © 2020 elisa. All rights reserved.
//

import SwiftUI

struct SignupView: View {
       
    @State private var email = ""
    @State private var password = ""
    @State private var confirmedPassword = ""
    
    @State private var formOffset: CGFloat = 0
    
    var body: some View {
        
       return VStack(spacing: 40) {
            Image("Logo")
            Text("Зарегистрироваться").font(.title).bold()
            VStack {
                LCTextfield(value: self.$email, placeholder: "Эл.почта", icon: Image(systemName: "at"), onEditingChanged: { flag in
                    withAnimation {
                        self.formOffset = flag ? -150 : 0
                    }
                    
                })
                LCTextfield(value: self.$password, placeholder: "Пароль", icon: Image(systemName: "lock"), isSecure: true)
                LCTextfield(value: self.$confirmedPassword, placeholder: "Повторите пароль", icon: Image(systemName: "lock.rotation"), isSecure: true)
                LCButton(text: "Создать аккаунт") {
                    
                }
            }
            
            Button(action: {
            }) {
              HStack {
                Text("Есть аккаунт?").accentColor(Color.accentColor)
                  }
              }
            
       }.padding().offset(y: self.formOffset)
    }
}

struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        SignupView()
    }
}
