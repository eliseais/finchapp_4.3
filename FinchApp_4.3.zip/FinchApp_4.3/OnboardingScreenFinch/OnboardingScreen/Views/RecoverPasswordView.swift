//
//  RecoverEmailView.swift
//  OnboardingScreen
//
//  Created by elisa on 17.05.2020.
//  Copyright © 2020 elisa. All rights reserved.
//

import SwiftUI

struct RecoverPasswordView: View {
    @State private var email = ""
    @Binding var presentPasswordRecoverySheet: Bool
    
    var body: some View {
        VStack(spacing: 40) {
            Image("Logo")
            Text("Восстановить пароль").font(.title).bold()
            VStack {
                LCTextfield(value: self.$email, placeholder: "Эл.почта", icon: Image(systemName: "at"))
                LCButton(text: "Сброс пароля") {}
            }
            
            Button(action: {
                self.presentPasswordRecoverySheet.toggle()
            }) {
              HStack {
                Text("Назад").accentColor(Color.accentColor)
                  }
              }
            
        }.padding()
    }

}

struct RecoverEmailView_Previews: PreviewProvider {
    static var previews: some View {
        RecoverPasswordView(presentPasswordRecoverySheet: .constant(false))
    }
}
