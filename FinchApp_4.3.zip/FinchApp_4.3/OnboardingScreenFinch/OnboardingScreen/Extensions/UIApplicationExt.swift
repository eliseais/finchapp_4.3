//
//  UIApplicationExt.swift
//  OnboardingScreen
//
//  Created by elisa on 17.05.2020.
//  Copyright © 2020 elisa. All rights reserved.
//


import SwiftUI


extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
