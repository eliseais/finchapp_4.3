//
//  Page.swift
//  OnboardingScreen
//
//  Created by elisa on 17.05.2020.
//  Copyright © 2020 elisa. All rights reserved.
//

import Foundation

struct Page: Identifiable {
    
    let id: UUID
    let image: String
    let heading: String
    let subSubheading: String
    
    static var getAll: [Page] {
        [
            Page(id: UUID(), image: "screen-1", heading: "Добро пожаловать в Finch", subSubheading: "Это социальная сеть для людей, которые хотят познать мир и хорошо отдохнуть"),
            Page(id: UUID(), image: "screen-2", heading: "Найди цель", subSubheading: "Среди всех путеводителей, тебе обязательно что-нибудь понравится. Мир велик"),
            Page(id: UUID(), image: "screen-3", heading: "Найди цель", subSubheading: "В поиске ты можешь найти весь материал по стране или городу, узнай самые интересные места"),
            Page(id: UUID(), image: "screen-4", heading: "Осуществи мечту", subSubheading: "Нашел все самое интересное? Тогда не жди момента, осуществи свою мечту прямо сейчас!")
            
        ]
    }
}
