//
//  NewViewController.swift
//  collectionTest
//
//  Created by Елизавета Андреянова on 25.04.2020.
//  Copyright © 2020 elisa. All rights reserved.
//

import UIKit

class NewViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goback(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func gobacktwo(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backnotes(_ sender: Any) {
       dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backtravel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backtraveltwo(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backhistory(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func BackSearch(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backlocation(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backfavourite(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backregister(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}

