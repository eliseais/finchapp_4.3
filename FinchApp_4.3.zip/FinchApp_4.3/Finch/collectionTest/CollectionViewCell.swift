//
//  CollectionViewCell.swift
//  collectionTest
//
//  Created by elisa on 07.04.2020.
//  Copyright © 2020 elisa. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var cellView: UIView!
    
    @IBOutlet var cellBackImage: UIImageView!
}
