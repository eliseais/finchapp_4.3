//
//  ViewController.swift
//  collectionTest
//
//  Created by elisa on 07.04.2020.
//  Copyright © 2020 elisa. All rights reserved.
//

import UIKit

struct Content: Codable {
    let contents: [ContentData]
}

struct ContentData: Codable {
    let id: Int
    let title: String
    let text: String
    let img: String
}

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet var my_collection: UICollectionView!
    @IBOutlet var my_table: UITableView!
    
    var mainPageContent = [ContentData]()

    private func readLocalFile(forName name: String) -> Data? {
        do {
            if let bundlePath = Bundle.main.path(forResource: name, ofType: "json"),
                let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                return jsonData
            }
        } catch {
            print(error)
        }

        return nil
    }
    
    private func parse(jsonData: Data) {
        do {
            let decodedData = try JSONDecoder().decode(Content.self, from: jsonData)
            mainPageContent = decodedData.contents
        } catch {
            print("\n Decode error \n")
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        if let localData = self.readLocalFile(forName: "mainContent") {
            self.parse(jsonData: localData)
        }
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == my_collection {
            return 5
        }

        return 3
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = my_collection.dequeueReusableCell(withReuseIdentifier: "my_cell", for: indexPath) as! CollectionViewCell

        cell.cellView.layer.cornerRadius = 15
        cell.cellView.clipsToBounds = true

        // рандомная картинка из двух
        let rand = Int.random(in: 0 ... 1)
        if rand == 1 {
            cell.cellBackImage.image = UIImage(named: "korea")
        } else {
            cell.cellBackImage.image = UIImage(named: "japan")
        }

        return cell
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mainPageContent.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = my_table.dequeueReusableCell(withIdentifier: "table_cell", for: indexPath) as! TableViewCell
        cell.titleLabel.text = mainPageContent[indexPath.row].title
        cell.textDescription.text = mainPageContent[indexPath.row].text
        cell.img.image = UIImage(named: mainPageContent[indexPath.row].img)
        return cell
    }
}
